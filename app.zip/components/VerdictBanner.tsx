import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { FullHealthReport } from '@/lib/types';

interface VerdictBannerProps {
    report: FullHealthReport;
}

export function VerdictBanner({ report }: VerdictBannerProps) {
    // Safety checks
    if (!report || !report.categories || !report.categories.problems) {
        return null;
    }

    const problems = report.categories.problems.tests || [];
    const errorCount = problems.filter(p => p.status === 'Error').length;
    const warningCount = problems.filter(p => p.status === 'Warning').length;

    // Strict verdict: Any error = Fail
    const isPassed = errorCount === 0;

    return (
        <div className={cn(
            "rounded-xl p-6 mb-8 border shadow-sm flex items-start sm:items-center justify-between gap-4",
            isPassed
                ? "bg-green-50 border-green-200 text-green-900"
                : "bg-red-50 border-red-200 text-red-900"
        )}>
            <div className="flex items-center gap-4">
                <div className={cn(
                    "p-3 rounded-full flex-shrink-0",
                    isPassed ? "bg-green-100" : "bg-red-100"
                )}>
                    {isPassed ? (
                        <CheckCircle2 className={cn("w-8 h-8", isPassed ? "text-green-600" : "text-green-600")} />
                    ) : (
                        <XCircle className="w-8 h-8 text-red-600" />
                    )}
                </div>
                <div>
                    <h2 className="text-xl font-bold tracking-tight">
                        {isPassed ? "All Systems Operational" : "Action Required"}
                    </h2>
                    <p className={cn("text-sm mt-1", isPassed ? "text-green-700" : "text-red-700")}>
                        {isPassed
                            ? "No critical issues detected. Your domain health is excellent."
                            : `${errorCount} critical issue${errorCount === 1 ? '' : 's'} detected. ${warningCount} warning${warningCount === 1 ? '' : 's'}.`
                        }
                    </p>
                </div>
            </div>

            {/* Action Button */}
            {!isPassed && (
                <div className="hidden sm:block">
                    <span className="inline-flex items-center px-4 py-2 rounded-lg bg-white/60 border border-red-200 text-red-800 text-sm font-semibold shadow-sm">
                        View Problems ↓
                    </span>
                </div>
            )}
        </div>
    );
}
