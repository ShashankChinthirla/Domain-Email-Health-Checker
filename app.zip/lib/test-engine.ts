import { promises as dns } from 'dns';
import { setServers } from 'dns';
import * as tls from 'tls'; // Used ONLY for HTTPS (Port 443) Certificate Check
import { checkDNSBL } from './dnsbl';
import { FullHealthReport, TestResult, CategoryResult, TestStatus } from './types';

// Force usage of Google & Cloudflare DNS for reliability
try {
    setServers(['8.8.8.8', '1.1.1.1', '8.8.4.4', '1.0.0.1']);
} catch (err) {
    console.warn('Failed to set strict DNS servers', err);
}

// Re-export for backend
export type { FullHealthReport, TestResult, CategoryResult, TestStatus };

// --- Helper: Create Category ---
function createCategory(name: string, tests: TestResult[]): CategoryResult {
    const stats = { passed: 0, warnings: 0, errors: 0 };
    for (const t of tests) {
        if (t.status === 'Pass') stats.passed++;
        if (t.status === 'Warning') stats.warnings++;
        if (t.status === 'Error') stats.errors++;
    }
    return { category: name, tests, stats };
}

// --- 1. DNS Tests (A, MX, SOA, NS, CAA) ---
async function runDNSTests(domain: string): Promise<TestResult[]> {
    const tests: TestResult[] = [];

    // A Record
    try {
        const a = await dns.resolve4(domain);
        tests.push({ name: 'A Record', status: 'Pass', info: `${a.length} IP(s) found` });
    } catch {
        tests.push({ name: 'A Record', status: 'Warning', info: 'Missing (IPv4)' });
    }

    // MX Record
    let mxRecords: string[] = [];
    try {
        const mxs = await dns.resolveMx(domain);
        mxRecords = mxs.sort((a, b) => a.priority - b.priority).map(m => m.exchange);
        tests.push({ name: 'MX Records', status: 'Pass', info: `${mxRecords.length} record(s) found` });

        // MX IP Resolution check (Passive)
        if (mxRecords.length > 0) {
            const primaryMx = mxRecords[0];
            try {
                const ips = await dns.resolve4(primaryMx);
                tests.push({ name: 'Primary MX Resolution', status: 'Pass', info: `${primaryMx} -> ${ips[0]}` });
            } catch {
                try {
                    await dns.resolve6(primaryMx);
                    tests.push({ name: 'Primary MX Resolution', status: 'Pass', info: `${primaryMx} -> IPv6` });
                } catch {
                    tests.push({ name: 'Primary MX Resolution', status: 'Error', info: `Could not resolve ${primaryMx}` });
                }
            }
        }
    } catch {
        tests.push({ name: 'MX Records', status: 'Error', info: 'No Mail Exchangers found' });
    }

    // NS Record
    try {
        const ns = await dns.resolveNs(domain);
        tests.push({ name: 'NS Records', status: 'Pass', info: `${ns.length} nameservers` });
        if (ns.length < 2) {
            tests.push({ name: 'NS Redundancy', status: 'Warning', info: 'Less than 2 nameservers' });
        }
    } catch {
        tests.push({ name: 'NS Records', status: 'Error', info: 'Missing' });
    }

    // SOA Record
    try {
        const soa = await dns.resolveSoa(domain);
        tests.push({ name: 'SOA Record', status: 'Pass', info: `Serial: ${soa.serial}` });
    } catch {
        tests.push({ name: 'SOA Record', status: 'Warning', info: 'Missing' });
    }

    // CAA Record (Security)
    try {
        const caa = await dns.resolveCaa(domain);
        tests.push({ name: 'CAA Record', status: 'Pass', info: `${caa.length} record(s)` });
    } catch (err: any) {
        // NODATA (code 0) is Pass (Optional), ENOTFOUND is Pass
        tests.push({ name: 'CAA Record', status: 'Pass', info: 'Not published (Optional)' });
    }

    return tests;
}


// --- 2. SPF Tests ---
async function runSPFTests(domain: string): Promise<{ tests: TestResult[], rawSpf: string | null }> {
    const tests: TestResult[] = [];
    let rawSpf: string | null = null;

    try {
        const txt = await dns.resolveTxt(domain);
        const spfRecords = txt.map(t => t.join('')).filter(s => s.toLowerCase().startsWith('v=spf1'));

        if (spfRecords.length === 0) {
            tests.push({ name: 'SPF Record', status: 'Error', info: 'Missing' });
            return { tests, rawSpf: null };
        }

        if (spfRecords.length > 1) {
            tests.push({ name: 'SPF Record', status: 'Error', info: 'Multiple SPF records found (Invalid)' });
            return { tests, rawSpf: spfRecords[0] };
        }

        rawSpf = spfRecords[0];
        tests.push({ name: 'SPF Record', status: 'Pass', info: 'Present' });

        // Syntax Checks
        if (rawSpf.includes('+all')) {
            tests.push({ name: 'SPF Policy', status: 'Error', info: '+all (Allows everyone)' });
        } else if (rawSpf.includes('-all')) {
            tests.push({ name: 'SPF Policy', status: 'Pass', info: 'Hard Fail (-all)' });
        } else if (rawSpf.includes('~all')) {
            tests.push({ name: 'SPF Policy', status: 'Pass', info: 'Soft Fail (~all)' });
        } else if (rawSpf.includes('?all')) {
            tests.push({ name: 'SPF Policy', status: 'Warning', info: 'Neutral (?all)' });
        } else if (rawSpf.includes('redirect=')) {
            tests.push({ name: 'SPF Policy', status: 'Pass', info: 'Redirects to another record' });
        } else {
            tests.push({ name: 'SPF Policy', status: 'Warning', info: 'No terminator found (e.g. -all)' });
        }

        // Lookup Count Estimate
        const lookupCount = (rawSpf.match(/include:|redirect=|mx|a:|ptr/g) || []).length;
        if (lookupCount > 10) {
            tests.push({ name: 'SPF Lookup Limit', status: 'Error', info: `${lookupCount} (> 10 max)` });
        } else {
            tests.push({ name: 'SPF Lookup Limit', status: 'Pass', info: `${lookupCount} (Safe)` });
        }

        if (rawSpf.includes('ptr')) {
            tests.push({ name: 'SPF "ptr" Mechanism', status: 'Warning', info: 'Deprecated/Slow' });
        }

    } catch {
        tests.push({ name: 'SPF Record', status: 'Error', info: 'Lookup Failed' });
    }

    return { tests, rawSpf };
}


// --- 3. DMARC Tests ---
async function runDMARCTests(domain: string): Promise<{ tests: TestResult[], rawDmarc: string | null }> {
    const tests: TestResult[] = [];
    let rawDmarc: string | null = null;

    try {
        const txt = await dns.resolveTxt(`_dmarc.${domain}`);

        // Robust Flattening Logic (as requested)
        // 1. Join chunks of each record
        // 2. Join all records (in case split across rows incorrectly)
        const flat = txt.map(parts => parts.join('')).join('');
        const record = flat.trim(); // Keep case for display, compare lower

        if (!record.toLowerCase().includes('v=dmarc1')) {
            tests.push({ name: 'DMARC Record', status: 'Warning', info: 'Missing' });
            return { tests, rawDmarc: null };
        }

        // It exists!
        rawDmarc = record;
        tests.push({ name: 'DMARC Record', status: 'Pass', info: 'Present' });

        // Policy Analysis
        const pMatch = record.match(/p=(\w+)/i);
        const policy = pMatch ? pMatch[1].toLowerCase() : 'none';

        if (policy === 'reject') {
            tests.push({ name: 'DMARC Policy', status: 'Pass', info: 'Reject (Maximum Security)' });
        } else if (policy === 'quarantine') {
            tests.push({ name: 'DMARC Policy', status: 'Pass', info: 'Quarantine (Secure)' });
        } else {
            // Valid DMARC but weak policy -> Warning, not Error (Parity with MxToolbox)
            tests.push({ name: 'DMARC Policy', status: 'Warning', info: `p=${policy} (No enforcement)` });
        }

        // Reporting
        if (record.toLowerCase().includes('rua=')) {
            tests.push({ name: 'DMARC Reporting (RUA)', status: 'Pass', info: 'Enabled' });
        } else {
            tests.push({ name: 'DMARC Reporting (RUA)', status: 'Warning', info: 'Missing (No data reports)' });
        }

        // PCT (Percent)
        const pctMatch = record.match(/pct=(\d+)/i);
        if (pctMatch && parseInt(pctMatch[1]) < 100) {
            tests.push({ name: 'DMARC Percentage', status: 'Warning', info: `${pctMatch[1]}% (Not applied to all)` });
        }

    } catch {
        tests.push({ name: 'DMARC Record', status: 'Warning', info: 'Missing' });
    }

    return { tests, rawDmarc };
}


// --- 4. DKIM Tests (Selector Guessing) ---
async function runDKIMTests(domain: string): Promise<TestResult[]> {
    const tests: TestResult[] = [];
    const selectors = ['default', 'google', 'mail', 'k1', 'smtp', 'selector1', '2023'];
    let found = false;

    for (const sel of selectors) {
        try {
            const txt = await dns.resolveTxt(`${sel}._domainkey.${domain}`);
            const record = txt.map(t => t.join('')).join('');
            if (record.includes('v=DKIM1') || record.includes('k=rsa')) {
                tests.push({ name: `Selector "${sel}"`, status: 'Pass', info: 'Record found' });
                found = true;
            }
        } catch {
            // Continue searching
        }
    }

    if (!found) {
        tests.push({ name: 'Common Selectors', status: 'Warning', info: 'None found (This is common if custom selectors are used)' });
    }

    return tests;
}


// --- 5. Blacklist (Safe IP Check) ---
async function runBlacklistTestsWithMX(mxRecords: string[]): Promise<TestResult[]> {
    if (mxRecords.length === 0) return [{ name: 'Blacklist Check', status: 'Warning', info: 'No MX Records to check' }];

    // Resolve Primary MX IP
    let ip: string | null = null;
    try {
        const ips = await dns.resolve4(mxRecords[0]);
        ip = ips[0];
    } catch {
        return [{ name: 'MX IP Resolution', status: 'Error', info: 'Could not resolve MX IP' }];
    }

    // Run existing logic
    const results = await checkDNSBL(ip);
    return results.map(res => ({
        name: res.list,
        status: res.isListed ? 'Error' : 'Pass',
        info: res.isListed ? 'Listed' : 'Clean'
    }));
}


// --- 6. Web Server (HTTPS + Cert) ---
// Allowed: Port 443 only.
async function runWebServerTests(domain: string): Promise<TestResult[]> {
    const tests: TestResult[] = [];

    // 1. Basic Availability (Fetch)
    try {
        const res = await fetch(`https://${domain}`, { method: 'HEAD', signal: AbortSignal.timeout(5000) });
        tests.push({ name: 'HTTPS Availability', status: res.ok || res.status < 500 ? 'Pass' : 'Warning', info: `Status ${res.status}` });
    } catch {
        tests.push({ name: 'HTTPS Availability', status: 'Warning', info: 'Unreachable' });
    }

    // 2. Certificate Details (TLS Socket)
    // This is NOT an "Attack", it's a standard browser-like handshake.
    try {
        await new Promise<void>((resolve, reject) => {
            const socket = tls.connect(443, domain, { servername: domain, rejectUnauthorized: false }, () => {
                const cert = socket.getPeerCertificate();
                if (cert && cert.valid_to) {
                    const validTo = new Date(cert.valid_to);
                    const daysLeft = Math.floor((validTo.getTime() - Date.now()) / (1000 * 60 * 60 * 24));

                    if (daysLeft < 0) {
                        tests.push({ name: 'SSL Certificate', status: 'Error', info: 'Expired' });
                    } else if (daysLeft < 14) {
                        tests.push({ name: 'SSL Certificate', status: 'Warning', info: `Expires in ${daysLeft} days` });
                    } else {
                        tests.push({ name: 'SSL Certificate', status: 'Pass', info: `Valid (${daysLeft} days left)` });
                    }

                    if (socket.authorized) {
                        tests.push({ name: 'SSL Chain', status: 'Pass', info: 'Valid' });
                    } else {
                        // socket.authorized is true only if rejectUnauthorized is true? 
                        // With rejectUnauthorized: false, we check socket.authorizationError
                        if (socket.authorizationError) {
                            tests.push({ name: 'SSL Chain', status: 'Warning', info: socket.authorizationError.message });
                        } else {
                            tests.push({ name: 'SSL Chain', status: 'Pass', info: 'Valid' });
                        }
                    }
                } else {
                    tests.push({ name: 'SSL Certificate', status: 'Error', info: 'No Certificate presented' });
                }
                socket.end();
                resolve();
            });

            socket.on('error', (err) => {
                tests.push({ name: 'SSL Handshake', status: 'Warning', info: err.message });
                resolve();
            });

            socket.setTimeout(5000, () => {
                socket.destroy();
                resolve();
            });
        });
    } catch {
        // Handled inside
    }

    return tests;
}


// --- Main Runner Orchestrator ---
export async function runFullHealthCheck(domain: string): Promise<FullHealthReport> {

    // 1. Run DNS First to get MX for Blacklist
    const dnsResults = await runDNSTests(domain);

    // Extract MX records from the DNS results (or re-fetch, easier to just re-fetch for cleaner code flow)
    let mxRecords: string[] = [];
    try {
        const mxs = await dns.resolveMx(domain);
        mxRecords = mxs.sort((a, b) => a.priority - b.priority).map(m => m.exchange);
    } catch { }

    // 2. Run All Suites in Parallel
    const [spfRes, dmarcRes, dkimRes, blacklistRes, webRes] = await Promise.all([
        runSPFTests(domain),
        runDMARCTests(domain),
        runDKIMTests(domain),
        runBlacklistTestsWithMX(mxRecords),
        runWebServerTests(domain)
    ]);

    // 3. Aggregate Problems
    const allTests = [
        ...dnsResults,
        ...spfRes.tests,
        ...dmarcRes.tests,
        ...dkimRes,
        ...blacklistRes,
        ...webRes
    ];

    const problems = allTests.filter(t => t.status !== 'Pass');

    return {
        domain,
        rawSpf: spfRes.rawSpf,
        rawDmarc: dmarcRes.rawDmarc,
        dmarcPolicy: null, // extracted in UI or inside dmarcRes
        mxRecords,
        categories: {
            problems: createCategory('Problems', problems),
            dns: createCategory('DNS', dnsResults),
            spf: createCategory('SPF', spfRes.tests),
            dmarc: createCategory('DMARC', dmarcRes.tests),
            dkim: createCategory('DKIM', dkimRes),
            blacklist: createCategory('Blacklist', blacklistRes),
            webServer: createCategory('Web Server', webRes)
        }
    };
}
