export type TestStatus = 'Pass' | 'Warning' | 'Error';

export interface TestResult {
    name: string;
    status: TestStatus;
    info: string;
}

export interface CategoryResult {
    category: string;
    tests: TestResult[];
    stats: {
        passed: number;
        warnings: number;
        errors: number;
    };
}

export interface FullHealthReport {
    domain: string;
    rawSpf: string | null;
    rawDmarc: string | null;
    dmarcPolicy: string | null;
    mxRecords: string[];
    categories: {
        problems: CategoryResult;
        dns: CategoryResult;
        spf: CategoryResult;
        dmarc: CategoryResult;
        dkim: CategoryResult;
        blacklist: CategoryResult;
        webServer: CategoryResult;
    };
}
